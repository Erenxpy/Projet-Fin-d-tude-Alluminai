<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;
use JsonSchema\Constraints\Constraint;

class CreateLoginTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
                'userName'=>[
                    'type'=>'VARCHAR' ,
                    'Constraint'=>'255'],
            'email'=>[
                'type'=>'VARCHAR' ,
                    'Constraint'=>'255'
            ],
            'password'=>[
                'type'=>'VARCHAR' ,
                    'Constraint'=>'255'
            ],
            'created_at timestamp default current_timestamp',
            'updated_at timestamp default current_timestamp on update current _timestamp',
            
       ] );
       $this->forge->addkey('userName',true);
       $this->forge->createTable('Login');
    }

    public function down()
    {
        $this->forge->dropTable('Login');
    }
}
