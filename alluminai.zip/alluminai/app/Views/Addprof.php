<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Professor</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            position: relative;
            margin-bottom: 20px;
        }
        .form-style {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .input-icon {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: #aaa;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .return-btn {
            text-align: center;
            margin-top: 20px;
        }
        .return-btn a {
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
            transition: color 0.3s;
        }
        .return-btn a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h4 class="mb-3 pb-3">Add a Professor</h4>
  
    <form method="post" action="doAddProf">
        <div class="form-group">
            <input type="text" class="form-style" name="Nom" placeholder="Name" >
            <i class="input-icon uil uil-user"></i>
        </div>
        <div class="form-group mt-2">
            <input type="text" name="Prenom" class="form-style" placeholder="Surname">
            <i class="input-icon uil uil-user"></i>
        </div>
        <div class="form-group mt-2">
            <input type="email" name="Email_prof" class="form-style" placeholder="Email">
            <i class="input-icon uil uil-at"></i>
        </div>
        <div class="form-group mt-2">
            <input type="tel" name="NumTel_Prof" class="form-style" placeholder="Phone">
            <i class="input-icon phone"></i>
        </div>
        <div class="form-group mt-2">
            <input type="text" name="Module" class="form-style" placeholder="Field">
            <i class="input-icon uil"></i>
        </div>
        <div class="form-group mt-2">
            <input type="text" name="grade" class="form-style" placeholder="Grade">
            <i class="input-icon uil"></i>
        </div>
        <div class="form-group mt-2">
            <select type="text" name="Departement" class="form-style" placeholder="Department">
                <option value="Informatique">Informatique</option>
                <option value="Medecine">Medicine</option>
                <option value="Physique">Physics</option>
                <option value="Chimie">Chemistry</option>
                <option value="Biologie">Biology</option>
            </select>
            <i class="input-icon uil uil-at"></i>
        </div>
        <a href="V-Admin"><input type="submit" class="btn mt-4" value="Confirm" /></a>
    </form>
    <div class="return-btn">
        <a href="V-Admin">Return</a>
    </div>
</div>
</body>
</html>
