<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>List prof</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet"  type="css/text" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
  <link  rel="stylesheet"  type="css/text" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url().'styless.css'; ?>">

   
</head>
<body>
<div class="topbar">
        <div class="brand">ALLUMINAI</div>
        <div class="menu">
            <ul><a href="welcome" class="nev">Home</a>
                <a href="V-home" class="nev">List of proffessors</a>
                <a href="University" class="nev">University</a>  
                <a href="contactUs" class="nev">Contact us</a>
                  
            </ul>
        </div>
    </div>

  

<table id="exampl" class="table table-striped dt-responsive" style="width:80%">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prenom</th>
                <th>contact</th>
                <th>Departement</th>
                <th>Phone</th>
                <th>Domaine</th>
                <th>Grade</th>
            </tr>
        </thead>
        <tbody>
          <?php if(isset($listOfProf)){
              foreach($listOfProf as $pr){?>
        <tr>
                <td><?=$pr['Nom']?></td>
                <td><?=$pr['Prenom']?></td>
                <td><?=$pr['Email_prof']?></td>
                <td><?=$pr['Departement']?></td>
                <td><?=$pr['NumTel-Prof']?></td>
                <td><?=$pr['Module']?></td>
                <td><?=$pr['grade']?></td>
          </tr>
          <?php }}?>
        </tbody>
  </table>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>


<script>
$(document).ready(function() {
    $('#exampl').DataTable();
});
</script>
  </body>

</html>
