<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ContactUs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo base_url().'styleus.css'; ?>">
</head>

<body>
    <div class="topbar">
        <div class="brand">ALLUMINAI</div>
        <div class="menu">
            <ul>
              <a href="welcome" class="nev">Home</a>
                <a href="V-home" class="nev">List of proffessors</a>
                <a href="University" class="nev">University</a>               
                <a href="contactUs" class="nev">Contact us</a>
                 
            </ul>
        </div>
    </div>
</body>


<small>Enter message (optional) and click button "Send"</small>
<small>Tell us if you are a Profesor we will try to contact you</small>
<div class="wrapper centered">
  <article class="letter">
    <div class="side">
      <h1>Contact us</h1>
      <p>
        <textarea placeholder="Your message"></textarea>
      </p>
    </div>
    <div class="side">
      <p>
        <input type="text" placeholder="Your name">
      </p>
      <p>
        <input type="email" placeholder="Your email">
      </p>
      <p>
        <button id="sendLetter">Send</button>
      </p>
    </div>
  </article>
       
     <div class="envelope front"></div>
     <div class="envelope back"></div>

    
</div>
<p class="result-message centered">Thank you for your message</p>

<script  type='text/javascript' src="account.js"></script>


<button class="Btn">
  
  <div class="sign"><svg viewBox="0 0 512 512"><path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path></svg></div>
  
  <a href="index" class="text">Logout</a>
  
</button>


