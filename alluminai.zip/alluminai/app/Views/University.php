<!doctype html>
<html lang="en">
<head>
  <title>Webleb</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo base_url().'styless.css' ?>">

    <style>
      html, body {
        overflow-x: hidden;
      }
    </style>
</head>

<body>
    <div class="topbar">
        <div class="brand">ALLUMINAI</div>
        <div class="menu">
            <ul>
                <a href="welcome" class="nev">Home</a>
                <a href="V-home" class="nev">List of proffessors</a>
                <a href="University" class="nev">University</a>              
                <a href="contactUs" class="nev">Contact us</a>
               
                
            </ul>
        </div>
    </div>
</body>
</div>
<body style="height: 100%; min-height: 100vh;">
        <div class="row">
              <div id="carouselId" class="carousel slide" data-bs-ride="carousel" >
                <ol class="carousel-indicators">
                  <li data-bs-target="#carouselId" data-bs-slide-to="0" class="active" aria-current="true" aria-label="First slide"></li>
                  <li data-bs-target="#carouselId" data-bs-slide-to="1" aria-label="Second slide"></li>
                  <li data-bs-target="#carouselId" data-bs-slide-to="2" aria-label="Third slide"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                  <div class="carousel-item active">
                    <img src="C:\alluminai\public\med.jpg" class="w-100 d-block" alt="First slide">
                  </div>
                  <div class="carousel-item">
                    <img src="C:\alluminai\public\dish.jpg" class="w-100 d-block" alt="Second slide" >
                  </div>
                  <div class="carousel-item">
                    <img src="C:\alluminai\public\rectorat.jpg" class="w-100 d-block" alt="Third slide" >
                  </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselId" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselId" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                  </button>
          </div>
        </div>
        <div>
          <div class="row justify-content-center" style="text-align: center; margin: 50px;">
            <h1>Université Badji Mokhtar d'Annaba</h1>
             <p>L'université Badji Mokhtar Annaba (UBMA) (arabe : جامعة باجي مختار - عنابة) est l'une des plus grandes universités algériennes, située à Annaba, sur la côte nord-est de l'Algérie. Elle porte le nom du chahid Badji Mokhtar militant politique et indépendantiste algérien, un des 22 chefs historiques responsables du déclenchement de la Guerre d'Algérie.
            </p>
            <h2>Historique</h2>
            <p>Créée par ordonnance 28/75 du 29 avril 1975 à partir des infrastructures de l'institut des Mines et Métallurgie d'Annaba, l'Université d'Annaba a connu un développement progressif avec l'ouverture de nouvelles filières chaque année. Structurée d'abord en départements rattachés au Rectorat, l'université a vu en 1980, la création de cinq instituts (Sciences sociales, Langues et littérature arabe, Sciences de la nature, Sciences exactes et Technologie, Sciences médicales3)6,7
            
              En 1993,elle fonctionnait avec 20 Instituts rattachés à trois grandes familles de filières :
              
              Sciences fondamentales.
              Sciences des technologies.
              Sciences Humaines et Sociales. 
              Assurant, anciennement, une formation polyvalente dans les profils de D.E.S, Licence, Ingénieur, et Technicien supérieur (DEUA), l'Université d'Annaba a été pionnière dans l'adoption du nouveau système LMD. À prédominance technologique, elle conserve cependant une tradition de sciences humaines développées dès sa création. Ces éléments en font un lieu privilégié pour l'interdisciplinarité et l'interpénétration avec son environnement social et industriel.</p>
            <h2>Implantations et Organisation</h2>
            <p>Depuis 1999, l'université est restructurée en sept (07) facultés regroupant 39 départements.

              Actuellement, les structures de l'Université d'Annaba sont implantées sur quatre pôles universitaires3,8,9,6 :
              
              Pôle universitaire Sidi Amar (Annaba):
              
              Rectorat
              Faculté des Sciences
              Faculté des Sciences de l'Ingénieur
              Faculté des Sciences de la Terre
              Pôle universitaire Ahmed El Bouni:
              
              Faculté de Droit
              Faculté de Médecine
              Faculté des Lettres, Sciences Humaines et Sociales
              Pôle universitaire Sidi Achour :
              
              Faculté des Sciences économiques et des Sciences de gestion
              Pôle universitaire Annaba centre (Ex.INESM):
              
              Faculté de Médecine</p>
            </div>
        </div>
      </div>
    </div>
  <!-- Bootstrap JavaScript Libraries -->

  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" 
   integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>
</body>
</html>
