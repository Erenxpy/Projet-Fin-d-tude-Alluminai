<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Home</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-Uv9jxBenhLL1+qzfUyxk5wrP+L5qvhwLTP60qjzTpL8=" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url().'styles.css'; ?>">

  <!-- Libraries CSS Files -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/latest/css/all.min.css" integrity="sha512-Yi+QvDkqQrwCkWQ2jWkWIEoir+x6pzl54Z2p7z89cMj5LIusMVXLfm3ocN5CDeN39xTqgeJ7Ldbf/CWkWCoqGxw==" crossorigin="anonymous" referrerpolicy="no-referrer">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<link href="https://unpkg.com/ionicons@4.5.10-0/dist/css/ionicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">
<link rel="stylesheet"type="css/text" href="<?php echo base_url().'styles.css'; ?>">

  <!-- Main Stylesheet File -->
  
  
</head>

<body id="page-top">

    <!--/ Nav Star /-->
    
            <body>
                <div class="topbar">
                    <div class="brand">ALLUMINAI</div>
                    <div class="menu">
                        <ul>
                            <a href="welcome" class="nev">Home</a>
                            <a href="V-home" class="nev">List of proffessors</a>
                            <a href="University" class="nev">University</a>
                            <a href="contactUs" class="ctaButton">Contact Us</a>
                            
                        </ul>
                    </div>
                </div>
            </body>
        </div>
    </nav>
    <!--/ Nav End /-->
    <!--/ Intro Skew Star /-->
    <div id="home" class="intro route bg-image" style="background-image: url(https://www.chalmers.se/_next/image/?url=https%3A%2F%2Fcms.www.chalmers.se%2FMedia%2Fmb3hi4kn%2Fcoding-7-1920.jpg%3Fwidth%3D1920%26height%3D1080%26rnd%3D133293116108230000%26quality%3D60%26format%3Dwebp&w=3840&q=85)">
        <div class="overlay-itro"></div>
        <div class="intro-content display-table">
            <div class="table-cell">
                <div class="container">
                    <h1 class="intro-title mb-4">ALUMINI</h1>
                    <p class="intro-subtitle"><span class="text-slider-items">Web Developer,Full-stack Developer, Web Designer</span><strong class="text-slider"></strong></p>
             
                </div>
            </div>
        </div>
    </div>
    <!--/ Intro Skew End /-->

    <section id="about" class="about-mf sect-pt4 route">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="box-shadow-full">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-sm-6 col-md-5">
                                        <div class="about-img">
                                            <img src="https://imageio.forbes.com/blogs-images/forbestechcouncil/files/2019/01/canva-photo-editor-8-7.jpg?height=640&width=640&fit=bounds" class="img-fluid rounded b-shadow-a" alt="">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-7">
                                        <div class="about-info">
                                            <p><span class="title-s">Name: </span> <span>Hamdaoui Ziad Sabri & Maalem Youcef</span></p>
                                            <p><span class="title-s">Email: </span> <span>ziad.7rm@gmail.com</span></p>
                                            <p><span class="title-s">Github: </span> <span>ErenJaegerForCodes</span></p>
                                        </div>
                                    </div>
                                </div>
                                
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="about-me pt-4 pt-md-0">
                                    <div class="title-box-2">
                                        <h5 class="title-left">
                                            About ALLUMINAI
                                        </h5>
                                    </div>
                                    <p class="lead">
                                       Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel luctus turpis. Ut sodales facilisis rhoncus. Quisque sed ex aliquet, ullamcorper leo ac, pellentesque tellus. Sed fringilla gravida sapien in semper. Etiam elementum, turpis at hendrerit fermentum, orci magna feugiat lectus, eget porta arcu velit in tortor. Aenean scelerisque metus erat, in cursus tortor sodales id. Morbi fermentum sed lorem quis maximus. Vivamus sem augue, laoreet at finibus non, hendrerit sit amet erat.
                                    </p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="copyright-box">
                            <p class="copyright">© All Rights Reserved</p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </section>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-Uv9jxBenhLL1+qzfUyxk5wrP+L5qvhwLTP60qjzTpL8=" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-migrate-3.4.1.min.js" integrity="sha256-KsRjqSIvQznv43EKdppYBn6tNtGKSQp7D4qU2P8N/uY=" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-wHNqQXa6a5X6i67C4GvKNiiOUa7M7VYkPStStjqO5jWrGGIC8dQjNIlWZq8Aysu+" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jY3zHTnfnHGOMHu1vUPEN8C9zFveqN+" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/easing/3.0.0/easing.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js" integrity="sha512-SJ2Kfkzp69PgNOUuhWh8lvzjohnnoPCNKnrOEoMaPtCL8z4HTtW/xPtOQSZKpFN0UFbU/DG2bm3s2zM8FFIlcA==" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/CounterUp/2.3.0/jquery.counterup.min.js" integrity="sha512-eZYtkXONaC9By3XGZ/PN4PNac4rN3tK8upQ9U9jR73HGjXup0YXF+r+r0CFhi2Dn24y8U8B8ZXaGQCv73yA==" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-hzTunOHHWha0HxhiiSXL4UWCBRa/TCZCrsc5xwKJqFsLf/GJ2zBV/ONuDX9WcusnYbE7AWem/qEtqDM7DjvwTlw==" crossorigin="anonymous"></script>

    <script type="text/javascript">
        if(window.history.replaceState){
        window.history.replaceState(null, null, window.location.href);
        }
    </script>
    <script type="text/javascript" src="adminjss.js"></script>

</body>
</html>
