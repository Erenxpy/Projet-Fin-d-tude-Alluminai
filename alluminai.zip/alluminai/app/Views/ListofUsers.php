<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <title>List of Users</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"  href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'styless.css'; ?>">

    <style>
        .btn-primary {
            background-color: blue;
            border-color: darkblue;
        }
        
        .btn-danger {
            background-color: red;
            border-color: darkred;
        }
        .Btn .text {
      color: #007bff;
      text-decoration: none;
    }
    .Btn .text:hover {
      text-decoration: underline;
    }
  
    </style>
</head>
<body>
    <div class="topbar">
        <div class="brand">Admin Side</div>
        <div class="menu">
            <ul>
                <a href="Admin" class="nev">List of proffessors</a>
                <a href="ListofUsers" class="nev">List of Users</a>
            </ul>
        </div>
    </div>

    <table id="abc" class="table table-striped table-bordered dt-responsive" style="width:100%">
        <thead>
            <tr>
                <th class="text-center">id</th>
                <th class="text-center">name</th>
                <th class="text-center">Phone</th>
                <th class="text-center">Email</th>
                <th class="text-center">Action</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if(isset($ListofUsers)){
                foreach($ListofUsers as $pr){?> 
            <tr>
                <td class="text-center"><?=$pr['id']?></td>
                <td class="text-center"><?=$pr['name']?></td>
                <td class="text-center"><?=$pr['Phone']?></td>
                <td class="text-center"><?=$pr['Email']?></td>
                <td class="text-center"><button type="button" class="btn btn-primary">Edit</button> 
                 <button type="button" class="btn btn-danger">Delete</button></td>
            </tr>
            <?php }}?>
        </tbody>
    </table>

    <div class="container text-center">
    <button class="Btn">
      <div class="sign">
        <svg viewBox="0 0 512 512">
          <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
        </svg>
      </div>
      <a href="index" class="text">Logout</a>
    </button>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#abc').DataTable();
        });
       

    </script>
    
</body>
</html>
