<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::Login');
$routes->get('/login', 'Home::Login');

$routes->post('/doLogin', 'Login::auth');
$routes->post('/doRegister', 'Login::register');

$routes->get('/Admin', 'Login::Admin');

$routes->get('/ListofUsers', 'Login::User');
$routes->get('/V-home', 'Login::Home');
$routes->get('/V-Admin', 'Login::Admin');
$routes->get('/V-home', 'Home::vHome');
$routes->get('/University', 'Home::univ');
$routes->get('/contactUs', 'Home::contact');
$routes->get('/index', 'Home::logout');

$routes->get('/ContactUs', 'Home::welabs');
$routes->get('/V-home', 'Home::welLp');
$routes->get('/welcome', 'Home::vHome');
$routes->get('/University', 'Home::univ');
$routes->get('/Addprof', 'Home::Add');
$routes->get('/V-Admin', 'Home::Radd');

$routes->post('/doAddProf', 'Login::Addprof');
/*$routes->delete('V-Admin','Home::Delete');*/