<?php

namespace App\Controllers;



class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }
    
    public function login()
    {
       
        return view('index');
    }
    public function univ()
    {
       
        return view('University');
    }
    public function vHome()
    {
       
        return view('welcome');
    }
    
    public function Listp()
    {
       
        return view('V-home');
    }

    public function contact()
    {
       
        return view('contactUs');
    }
    public function logout()
    {
       
        return view('index');
    }
   
   
    public function WelLp()
    {
       
        return view('V-home');
    }

    public function Add()
    {
       
        return view('AddProf');
    }
    public function Radd()
    {
       
        return view('V-Admin');
    }
  
    
    
}
