<?php namespace App\Controllers;
  
use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\profmodel;

class Login extends Controller
{
    /**
     * Open a session using a password and an email.
     */
    public function auth()
    {
        $session = session();
        $model = new UserModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        if (empty($email) or empty($password)) {
            $session->setFlashdata('msg', 'Les informations de login ne peuvent être vides!');
            return redirect()->to('/login');
        }

        $data = $model->where('Email', $email)->first();

        if ($data) {
            $pass = $data['Password'];
            //$verify_pass = password_verify($password, $pass);

            if ($password==$pass) {
                
                if ($data['role'] == 1) { //Admin
                    return redirect()->to('/Admin');
                } elseif ($data['role'] == 2) { //professor
                    return redirect()->to('/welcome');
                }
            } else {
                $session->setFlashdata('msg', 'Le mot de passe est incorrect !');
                return redirect()->to('/login');
            }
        } else {
            $session->setFlashdata('msg', 'Cette adresse email n\'existe pas!');
            return redirect()->to('/login');
        }
    }
  
    public function logout()
    {
        $session = session();
        log_message('info',' User logged out'.$session->get('email'));
        $session->destroy();
        return redirect()->to('/Login');
    }
    public function register(){
        $session = session();
        $model = new UserModel();
        $data["name"] =$this->request->getVar('name');
        $data["Phone"] =$this->request->getVar('phone');
        $data["Email"] = $this->request->getVar('email');
        $data["Password"]= $this->request->getVar('password');
        $data["role"]=2;// a simple user.
        $model->insert($data);
        return redirect()->to('/welcome');        
    }
    public function Admin(){

        $prfM=new profmodel();
        $data["listOfProf"]=$prfM->findAll();
        return view("V-Admin",$data);

        
    }

    public function Home(){

        $prfM=new profmodel();
        $data["listOfProf"]=$prfM->findAll();
        return view("V-home",$data);
    }
    
    public function User(){

        $UsrM=new UserModel();
        $data["ListofUsers"]=$UsrM->findAll();
        return view("ListofUsers",$data);
    }
    public function Addprof(){
        $session = session();
        $model = new profmodel();
        $data["Nom"] =$this->request->getVar('Nom');
        $data["Prenom"] =$this->request->getVar('Prenom');
        $data["Email_prof"] = $this->request->getVar('Email_prof');
        $data["NumTel-Prof"]= $this->request->getVar('NumTel_Prof');
        $data["Module"]= $this->request->getVar('Module');
        $data["grade"]= $this->request->getVar('grade');
        $data["Departement"]= $this->request->getVar('Departement');
        $data["role"]=2;
        $model->insert($data);
        return redirect()->to('/V-Admin');       
         
    }
    /*public function Delete($id)
    {
        $prfM=new profmodel();
        $prfM->Delete($id);
        return redirect()->to(base_url('/V-Admin'))->with('status','List Prof Updated Successfully');    
        
    }*/
}

